from setuptools import setup

setup(name='asgiref')
